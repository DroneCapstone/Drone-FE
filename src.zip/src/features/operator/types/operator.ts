export type Tone = 'success' | 'warning' | 'danger' | 'info' | 'neutral';

export type TechnicalStatus = 'Available' | 'Maintenance' | 'Battery Replacement';

export type MissionStatus =
  | 'Scheduled'
  | 'In Progress'
  | 'Completed'
  | 'Cancelled'
  | 'Failed';

export type MissionType = 'Delivery' | 'Return';

export type OrderStatus =
  | 'Pending'
  | 'Ready for Pickup'
  | 'Completed'
  | 'Returned'
  | 'Cancelled';

export type PickupState = 'Waiting' | 'Due Soon' | 'Grace Period' | 'Return Required';

export type ReturnStatus = 'None' | 'Return Planned' | 'Returning' | 'Returned to Hub';

export type PlanningState =
  | 'Planning Overdue'
  | 'Ready for Planning'
  | 'Upcoming'
  | 'Future';

export type PackageDisposition = 'Delivered' | 'Returned' | 'Disposed';

export type ReturnReason =
  | 'Customer Pickup Timeout'
  | 'Customer Declined'
  | 'Customer Unreachable'
  | 'Station Failure'
  | 'System Error'
  | 'Delivery Error'
  | 'Package Damaged';

export interface DeliveryWindow {
  start: string;
  end: string;
}

export interface OrderCharges {
  deliveryFee: number;
  returnFee?: number;
  penaltyFee?: number;
  refundAmount?: number;
  currency: 'VND';
}

export interface Order {
  id: string;
  customerName: string;
  customerPhone: string;
  packageLabel: string;
  packageType: string;
  payloadKg: number;
  pickupStationId: string;
  destinationStationId: string;
  requestedDate: string;
  initialEstimatedWindow: DeliveryWindow;
  currentEstimatedWindow: DeliveryWindow;
  planningAt: string;
  status: OrderStatus;
  readyForPickupAt?: string;
  pickupDeadline?: string;
  gracePeriodEndsAt?: string;
  pickupState?: PickupState;
  returnStatus?: ReturnStatus;
  returnReason?: ReturnReason;
  returnedAt?: string;
  packageDisposition?: PackageDisposition;
  charges?: OrderCharges;
  createdAt: string;
}

export interface DroneAssignmentHistory {
  droneId: string;
  droneName: string;
  replacedAt: string;
  reason: string;
}

export interface Mission {
  id: string;
  orderId: string;
  type: MissionType;
  name: string;
  droneId: string;
  drone: string;
  hubId: string;
  routeId: string;
  route: string;
  status: MissionStatus;
  tone: Tone;
  eta: string;
  battery: number;
  plannedStartAt: string;
  actualStartedAt?: string;
  actualCompletedAt?: string;
  estimatedArrivalAt: string;
  predictedDurationMin: number;
  estimatedEnergyWh: number;
  batteryConsumptionPct: number;
  confidencePct?: number;
  risk?: 'Low' | 'Medium' | 'High';
  scheduleState?: 'On Time' | 'Delayed';
  destinationSlotId?: string;
  assignmentHistory?: DroneAssignmentHistory[];
  createdAt: string;
}

export interface Hub {
  id: string;
  name: string;
  area: string;
  address: string;
  latitude: number;
  longitude: number;
  status: 'Active' | 'Inactive';
}

export interface OperatorDrone {
  id: string;
  name: string;
  model: string;
  hubId: string;
  technicalStatus: TechnicalStatus;
  battery: number;
  maxPayloadKg: number;
}

export type LockerStatus = 'Available' | 'Reserved' | 'Occupied' | 'Out of Service';

export interface LockerSlot {
  id: string;
  stationId: string;
  status: LockerStatus;
  orderId?: string;
  missionId?: string;
}

export interface Station {
  id: string;
  name: string;
  area: string;
  address: string;
  latitude: number;
  longitude: number;
  status: 'Active' | 'Unavailable';
  slots: LockerSlot[];
}

export interface WeatherSnapshot {
  temperatureC: number;
  humidityPct: number;
  windSpeedMs: number;
  windGustMs: number;
  windDirectionDeg: number;
  precipitationMm: number;
  cloudCoverPct: number;
  relativeWindAngleDeg: number;
}

export interface ShapFactor {
  feature: string;
  impactWh: number;
  direction: 'increase' | 'decrease';
  note: string;
}

export interface RouteOption {
  id: string;
  name: string;
  distanceKm: number;
  predictedDurationMin: number;
  predictedEnergyWh: number;
  batteryConsumptionPct: number;
  confidencePct: number;
  risk: 'Low' | 'Medium' | 'High';
  weatherImpact: string;
  recommended?: boolean;
  recommendationReasons: string[];
  tradeOff: string;
}

export interface RouteAiAnalysis {
  routeId: string;
  weather: WeatherSnapshot;
  shapFactors: ShapFactor[];
  operationalRisks: Array<{
    label: string;
    level: 'Low' | 'Medium' | 'High';
    detail: string;
  }>;
}

export interface DroneEligibilityResult {
  eligible: boolean;
  reasons: string[];
}

export interface MissionDraft {
  orderId: string;
  step: number;
  selectedHubId: string;
  selectedDroneId: string;
  selectedRouteId: string;
  updatedAt: string;
}

export interface OperatorNavItem {
  label: string;
  path: string;
  icon: import('../../../components/ui/Icon').IconName;
  children?: Array<{ label: string; path: string }>;
}
