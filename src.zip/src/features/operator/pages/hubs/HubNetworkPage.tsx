import { NavLink } from 'react-router-dom';
import { HubCard } from '../../components/HubCard';
import { OperatorPanel } from '../../components/OperatorPanel';
import { operatorHubs } from '../../data/hubMockData';
import { loadOperatorFleet } from '../../utils/operatorFleetStorage';
import { hasActiveMissionForDrone, loadOperatorMissions } from '../../utils/operatorMissionStorage';
import { FleetHubPageShell } from '../fleet/FleetHubPageShell';

export function HubNetworkPage() {
  const fleet = loadOperatorFleet();
  const missions = loadOperatorMissions();

  return (
    <FleetHubPageShell active="/operator/fleet-hubs/hubs">
      <OperatorPanel
        title="Hub network"
        eyebrow="OPERATIONAL OVERVIEW"
        action={<NavLink className="text-button" to="/operator/fleet-hubs/drones">View all drones</NavLink>}
      >
        <div className="hub-grid">
          {operatorHubs.map((hub) => {
            const hubDrones = fleet.filter((drone) => drone.hubId === hub.id);
            const readyDrones = hubDrones.filter(
              (drone) => drone.technicalStatus === 'Available' && !hasActiveMissionForDrone(drone.id, missions),
            );

            return <HubCard key={hub.id} hub={hub} totalDrones={hubDrones.length} readyDrones={readyDrones.length} />;
          })}
        </div>
        <p className="section-note">Ready now means the drone is technically available and is not already assigned to a Scheduled or In Progress mission. Payload and route energy are checked during mission planning.</p>
      </OperatorPanel>
    </FleetHubPageShell>
  );
}
