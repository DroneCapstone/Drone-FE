import { useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

import { ActionButton } from '../../../../components/ui/ActionButton';
import { StatusBadge } from '../../../../components/ui/StatusBadge';

import { OperatorPanel } from '../../components/OperatorPanel';
import { StationCapacity } from '../../components/StationCapacity';

import { getPickupState } from '../../utils/deliveryPlanning';
import { formatMissionTime } from '../../utils/missionTiming';
import { loadOperatorMissions } from '../../utils/operatorMissionStorage';
import { loadOperatorOrders } from '../../utils/operatorOrderStorage';
import { getStation } from '../../utils/stationCapacity';

import { FleetHubPageShell } from '../fleet/FleetHubPageShell';

export function StationDetailPage() {
  const { stationId = '' } = useParams();
  const navigate = useNavigate();

  const station = useMemo(() => getStation(stationId), [stationId]);

  const orders = useMemo(() => loadOperatorOrders(), []);

  const missions = useMemo(() => loadOperatorMissions(), []);

  /**
   * Quay về đúng Station Network.
   *
   * Không dùng navigate(-1) vì nếu user mở trực tiếp
   * Station Detail từ URL thì Back có thể quay về page không liên quan.
   */
  const handleBackToStationNetwork = () => {
    navigate('/operator/fleet-hubs/stations');
  };

  if (!station) {
    return (
      <FleetHubPageShell active="/operator/fleet-hubs/stations">
        <div style={{ marginBottom: 16 }}>
          <ActionButton
            variant="ghost"
            icon="collapse"
            onClick={handleBackToStationNetwork}
          >
            Back to Station Network
          </ActionButton>
        </div>

        <OperatorPanel>
          <div className="operator-empty-state">
            Station not found.
          </div>
        </OperatorPanel>
      </FleetHubPageShell>
    );
  }

  /**
   * Những Order đã được giao tới Station
   * và đang chờ Customer tới nhận.
   */
  const relevantOrders = orders.filter(
    (order) =>
      order.destinationStationId === station.id &&
      order.status === 'Ready for Pickup',
  );

  /**
   * Những Delivery Mission đang chuẩn bị tới Station
   * hoặc đang trong quá trình thực hiện.
   */
  const incomingMissions = missions.filter((mission) => {
    if (mission.type !== 'Delivery') {
      return false;
    }

    if (!['Scheduled', 'In Progress'].includes(mission.status)) {
      return false;
    }

    const linkedOrder = orders.find(
      (order) => order.id === mission.orderId,
    );

    return linkedOrder?.destinationStationId === station.id;
  });

  return (
    <FleetHubPageShell active="/operator/fleet-hubs/stations">
      {/* ============================= */}
      {/* BACK NAVIGATION */}
      {/* ============================= */}

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          marginBottom: 16,
        }}
      >
        <ActionButton
          variant="ghost"
          icon="collapse"
          onClick={handleBackToStationNetwork}
        >
          Back to Station Network
        </ActionButton>
      </div>

      {/* ============================= */}
      {/* STATION DETAIL */}
      {/* ============================= */}

      <div className="detail-layout">
        <div className="detail-main">
          {/* ============================= */}
          {/* STATION HERO */}
          {/* ============================= */}

          <OperatorPanel>
            <div className="mission-hero">
              <div>
                <StatusBadge tone="success">
                  {station.status}
                </StatusBadge>

                <h2>{station.name}</h2>

                <p>
                  {station.id} · {station.address}
                </p>
              </div>
            </div>
          </OperatorPanel>

          {/* ============================= */}
          {/* INCOMING PACKAGES */}
          {/* ============================= */}

          <OperatorPanel
            title="Incoming packages"
            eyebrow="RESERVED / INBOUND"
          >
            {incomingMissions.length === 0 ? (
              <div className="operator-empty-state">
                No incoming packages.
              </div>
            ) : (
              <div className="planning-queue">
                {incomingMissions.map((mission) => (
                  <button
                    type="button"
                    className="planning-queue-row"
                    key={mission.id}
                    onClick={() =>
                      navigate(
                        `/operator/missions/${mission.id}`,
                      )
                    }
                  >
                    <div>
                      <strong>
                        {mission.orderId}
                      </strong>

                      <small>
                        {mission.id} · {mission.drone}
                      </small>
                    </div>

                    <StatusBadge tone={mission.tone}>
                      {mission.status}
                    </StatusBadge>

                    <span className="row-action">
                      ETA {mission.eta}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </OperatorPanel>

          {/* ============================= */}
          {/* CUSTOMER PICKUP QUEUE */}
          {/* ============================= */}

          <OperatorPanel
            title="Package pickup queue"
            eyebrow="CUSTOMER HANDOFF"
          >
            {relevantOrders.length === 0 ? (
              <div className="operator-empty-state">
                No packages are waiting for pickup.
              </div>
            ) : (
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>Order</th>

                      <th>Package</th>

                      <th>Pickup state</th>

                      <th>Deadline</th>

                      <th />
                    </tr>
                  </thead>

                  <tbody>
                    {relevantOrders.map((order) => {
                      const pickupState =
                        getPickupState(order) ??
                        'Waiting';

                      const returnMission =
                        missions.find(
                          (mission) =>
                            mission.orderId ===
                            order.id &&
                            mission.type ===
                            'Return',
                        );

                      const pickupTone =
                        pickupState ===
                          'Return Required'
                          ? 'danger'
                          : pickupState ===
                            'Grace Period'
                            ? 'warning'
                            : pickupState ===
                              'Due Soon'
                              ? 'warning'
                              : 'info';

                      return (
                        <tr
                          key={order.id}
                          onClick={() =>
                            navigate(
                              `/operator/orders/${order.id}`,
                            )
                          }
                        >
                          <td>
                            <strong>
                              {order.id}
                            </strong>

                            <small>
                              {order.customerName}
                            </small>
                          </td>

                          <td>
                            {order.packageLabel}
                          </td>

                          <td>
                            <StatusBadge
                              tone={pickupTone}
                            >
                              {pickupState}
                            </StatusBadge>
                          </td>

                          <td>
                            {order.pickupDeadline
                              ? formatMissionTime(
                                order.pickupDeadline,
                              )
                              : '—'}
                          </td>

                          <td>
                            <button
                              type="button"
                              className="row-action"
                              onClick={(event) => {
                                event.stopPropagation();

                                if (
                                  returnMission
                                ) {
                                  navigate(
                                    `/operator/missions/${returnMission.id}`,
                                  );

                                  return;
                                }

                                navigate(
                                  `/operator/orders/${order.id}`,
                                );
                              }}
                            >
                              {returnMission
                                ? 'View return'
                                : pickupState ===
                                  'Return Required'
                                  ? 'Await auto-return'
                                  : 'View order'}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </OperatorPanel>
        </div>

        {/* ============================= */}
        {/* RIGHT SIDE */}
        {/* ============================= */}

        <aside className="detail-side">
          {/* ============================= */}
          {/* CAPACITY */}
          {/* ============================= */}

          <OperatorPanel title="Capacity">
            <StationCapacity station={station} />
          </OperatorPanel>

          {/* ============================= */}
          {/* STATION INFO */}
          {/* ============================= */}

          <OperatorPanel title="Station details">
            <dl className="key-values">
              <div>
                <dt>Area</dt>

                <dd>
                  {station.area}
                </dd>
              </div>

              <div>
                <dt>Address</dt>

                <dd>
                  {station.address}
                </dd>
              </div>

              <div>
                <dt>Role</dt>

                <dd>
                  Package drop-off / pickup
                </dd>
              </div>

              <div>
                <dt>
                  Maintenance scope
                </dt>

                <dd>
                  Not managed by Operator
                </dd>
              </div>
            </dl>
          </OperatorPanel>
        </aside>
      </div>
    </FleetHubPageShell>
  );
}