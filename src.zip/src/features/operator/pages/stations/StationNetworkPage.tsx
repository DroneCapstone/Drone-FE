import { useNavigate } from 'react-router-dom';
import { StatusBadge } from '../../../../components/ui/StatusBadge';
import { OperatorPanel } from '../../components/OperatorPanel';
import { StationCapacity } from '../../components/StationCapacity';
import { getPickupState } from '../../utils/deliveryPlanning';
import { loadOperatorMissions } from '../../utils/operatorMissionStorage';
import { loadOperatorOrders } from '../../utils/operatorOrderStorage';
import { loadStations } from '../../utils/stationCapacity';
import { FleetHubPageShell } from '../fleet/FleetHubPageShell';

export function StationNetworkPage() {
  const navigate = useNavigate();
  const stations = loadStations();
  const orders = loadOperatorOrders();
  const missions = loadOperatorMissions();

  return (
    <FleetHubPageShell active="/operator/fleet-hubs/stations">
      <OperatorPanel title="Station network" eyebrow="PACKAGE CAPACITY + HANDOFF">
        <div className="station-grid">
          {stations.map((station) => {
            const pickupExceptions = orders.filter((order) => order.destinationStationId === station.id && ['Grace Period', 'Return Required'].includes(getPickupState(order) ?? '')).length;
            const awaitingPickup = orders.filter((order) => order.destinationStationId === station.id && order.status === 'Ready for Pickup').length;
            const incoming = missions.filter((mission) => mission.type === 'Delivery' && ['Scheduled', 'In Progress'].includes(mission.status) && orders.find((order) => order.id === mission.orderId)?.destinationStationId === station.id).length;
            const returnTasks = missions.filter((mission) => mission.type === 'Return' && ['Scheduled', 'In Progress'].includes(mission.status) && orders.find((order) => order.id === mission.orderId)?.destinationStationId === station.id).length;

            return (
              <button type="button" className="station-card selectable-card" key={station.id} onClick={() => navigate(`/operator/stations/${station.id}`)}>
                <div className="station-card-head">
                  <div><small>{station.id}</small><h3>{station.name}</h3><p>{station.area}</p></div>
                  <StatusBadge tone={station.status === 'Active' ? 'success' : 'neutral'}>{station.status}</StatusBadge>
                </div>
                <StationCapacity station={station} />
                <div className="station-operations-grid">
                  <span><small>Incoming</small><strong>{incoming}</strong></span>
                  <span><small>Awaiting pickup</small><strong>{awaitingPickup}</strong></span>
                  <span><small>Pickup exceptions</small><strong>{pickupExceptions}</strong></span>
                  <span><small>Return tasks</small><strong>{returnTasks}</strong></span>
                </div>
              </button>
            );
          })}
        </div>
      </OperatorPanel>
    </FleetHubPageShell>
  );
}
