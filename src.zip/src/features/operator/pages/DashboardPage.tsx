import { useMemo, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { ActionButton } from '../../../components/ui/ActionButton';
import { Icon } from '../../../components/ui/Icon';
import { AreaChart } from '../components/AreaChart';
import { MetricCard } from '../components/MetricCard';
import { OperationalStateBar } from '../components/OperationalStateBar';
import { OperatorPanel } from '../components/OperatorPanel';
import { PageHeader } from '../components/PageHeader';
import { PlanningQueue } from '../components/PlanningQueue';
import { getOrderPlanningBadge, getPickupState, isActionablePlanningState } from '../utils/deliveryPlanning';
import { loadOperatorMissions } from '../utils/operatorMissionStorage';
import { loadOperatorOrders } from '../utils/operatorOrderStorage';

export function DashboardPage() {
  const navigate = useNavigate();
  const [period, setPeriod] = useState<'Today' | 'Week' | 'Month'>('Today');
  const orders = useMemo(() => loadOperatorOrders(), []);
  const missions = useMemo(() => loadOperatorMissions(), []);

  const readyOrders = orders.filter((order) => isActionablePlanningState(getOrderPlanningBadge(order, missions)));
  const planningOverdue = orders.filter((order) => getOrderPlanningBadge(order, missions) === 'Planning Overdue');
  const pickupGrace = orders.filter((order) => getPickupState(order) === 'Grace Period');
  const returnRequired = orders.filter((order) => getPickupState(order) === 'Return Required');
  const returnWaitingDispatch = missions.filter((mission) => mission.type === 'Return' && mission.status === 'Scheduled');
  const activeMissions = missions.filter((mission) => mission.status === 'In Progress');
  const scheduledMissions = missions.filter((mission) => mission.status === 'Scheduled');
  const completedMissions = missions.filter((mission) => mission.status === 'Completed');
  const failedMissions = missions.filter((mission) => mission.status === 'Failed' || mission.status === 'Cancelled');

  const periodData = {
    Today: { total: String(missions.length), delta: 'Live mission data', labels: ['06:00', '09:00', '12:00', '15:00', '18:00', '21:00'] },
    Week: { total: '32', delta: '+6.8% vs last week', labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] },
    Month: { total: '128', delta: '+4.1% vs last month', labels: ['W1', 'W2', 'W3', 'W4', 'Today', 'Forecast'] },
  }[period];

  const needsAttentionCount = planningOverdue.length + pickupGrace.length + returnRequired.length + returnWaitingDispatch.length;

  return (
    <>
      <PageHeader
        section="dashboard"
        action={
          <>
            {/* REPORT FEATURE DISABLED — snapshot export kept for future re-enable. */}
            {/* <ActionButton variant="secondary">Export snapshot</ActionButton> */}
            <ActionButton onClick={() => navigate('/operator/orders/ready')}>View planning queue</ActionButton>
          </>
        }
      />

      <OperationalStateBar />

      <div className="dashboard-grid lower primary-operations">
        <OperatorPanel title="Ready for planning" eyebrow="ORDER QUEUE" action={<NavLink className="text-button" to="/operator/orders/ready">View all</NavLink>}>
          <PlanningQueue orders={orders} missions={missions} />
        </OperatorPanel>

        <OperatorPanel title="Needs attention" eyebrow="ACTION REQUIRED" action={<span className="counter">{needsAttentionCount} open</span>}>
          <div className="alert-list">
            {planningOverdue[0] && (
              <button className="alert-row danger" type="button" onClick={() => navigate(`/operator/orders/${planningOverdue[0].id}`)}>
                <span className="alert-icon"><Icon name="clock" /></span><div><strong>Mission planning overdue</strong><small>{planningOverdue[0].id} · create a Flight Mission</small></div><Icon name="chevron" size={15} />
              </button>
            )}
            {pickupGrace[0] && (
              <button className="alert-row warning" type="button" onClick={() => navigate(`/operator/orders/${pickupGrace[0].id}`)}>
                <span className="alert-icon"><Icon name="clock" /></span><div><strong>Customer pickup in grace period</strong><small>{pickupGrace[0].id} · final follow-up before return</small></div><Icon name="chevron" size={15} />
              </button>
            )}
            {returnWaitingDispatch[0] && (
              <button className="alert-row warning" type="button" onClick={() => navigate(`/operator/missions/${returnWaitingDispatch[0].id}`)}>
                <span className="alert-icon"><Icon name="mission" /></span><div><strong>Return Mission waiting dispatch</strong><small>{returnWaitingDispatch[0].id} · {returnWaitingDispatch[0].orderId}</small></div><Icon name="chevron" size={15} />
              </button>
            )}
            <button className="alert-row warning" type="button" onClick={() => navigate('/operator/operations/incidents')}>
              <span className="alert-icon"><Icon name="wind" /></span><div><strong>Mission incident requires monitoring</strong><small>MSN-3110 · replacement drone active</small></div><Icon name="chevron" size={15} />
            </button>
          </div>
        </OperatorPanel>
      </div>

      <div className="dashboard-section-label"><span>TODAY’S OPERATING BASELINE</span><small>Order planning, Mission execution, and package handoff</small></div>

      <div className="metric-grid">
        <MetricCard label="Ready for planning" value={String(readyOrders.length).padStart(2, '0')} delta="Action" note={`${planningOverdue.length} planning overdue`} />
        <MetricCard label="Active missions" value={String(activeMissions.length).padStart(2, '0')} delta="Live" note={`${scheduledMissions.length} scheduled next`} />
        <MetricCard label="Pickup exceptions" value={String(pickupGrace.length + returnRequired.length).padStart(2, '0')} delta="Follow up" note={`${returnWaitingDispatch.length} return waiting dispatch`} />
        <MetricCard label="Completed missions" value={`${completedMissions.length}`} delta="Today" note="Delivery + return execution" />
      </div>

      <div className="dashboard-grid">
        <OperatorPanel
          title="Mission throughput"
          eyebrow="OPERATING PERIOD"
          className="chart-panel"
          action={<div className="segmented">{(['Today', 'Week', 'Month'] as const).map((item) => <button key={item} type="button" className={period === item ? 'active' : ''} onClick={() => setPeriod(item)}>{item}</button>)}</div>}
        >
          <div className="chart-summary"><strong>{periodData.total}</strong><span>total missions</span><span className="summary-delta">{periodData.delta}</span></div>
          <AreaChart orange variant="throughput" unit="missions / hour" yLabels={['40', '30', '20', '10']} pointLabel="Mission activity" />
          <div className="chart-labels">{periodData.labels.map((label) => <span key={label}>{label}</span>)}</div>
        </OperatorPanel>

        <OperatorPanel title="Flight Mission status" eyebrow="CURRENT" action={<NavLink className="text-button" to="/operator/missions/all">View all</NavLink>}>
          <div className="donut-wrap">
            <div className="donut"><div><strong>{missions.length}</strong><span>Total</span></div></div>
            <div className="donut-legend">
              <span><i className="green" />Completed <b>{completedMissions.length}</b></span>
              <span><i className="orange" />In progress <b>{activeMissions.length}</b></span>
              <span><i className="blue" />Scheduled <b>{scheduledMissions.length}</b></span>
              <span><i className="red" />Cancelled / Failed <b>{failedMissions.length}</b></span>
            </div>
          </div>
        </OperatorPanel>
      </div>
    </>
  );
}
