import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { DropdownSelect } from '../../../../components/ui/DropdownSelect';
import { Icon } from '../../../../components/ui/Icon';
import { DroneAvailabilityTable } from '../../components/DroneAvailabilityTable';
import { OperatorPanel } from '../../components/OperatorPanel';
import { operatorHubs } from '../../data/hubMockData';
import type { TechnicalStatus } from '../../types/operator';
import { loadOperatorFleet } from '../../utils/operatorFleetStorage';
import { FleetHubPageShell } from './FleetHubPageShell';

export function DroneAvailabilityPage() {
  const [searchParams] = useSearchParams();
  const initialHub = searchParams.get('hub') ?? 'All hubs';
  const [query, setQuery] = useState('');
  const [hubFilter, setHubFilter] = useState(initialHub);
  const [technicalFilter, setTechnicalFilter] = useState('All technical');
  const fleet = loadOperatorFleet();

  const filtered = useMemo(() => fleet.filter((drone) => {
    const matchesQuery = `${drone.name} ${drone.id} ${drone.model}`.toLowerCase().includes(query.toLowerCase());
    const matchesHub = hubFilter === 'All hubs' || drone.hubId === hubFilter;
    const matchesTechnical = technicalFilter === 'All technical' || drone.technicalStatus === (technicalFilter as TechnicalStatus);
    return matchesQuery && matchesHub && matchesTechnical;
  }), [fleet, hubFilter, query, technicalFilter]);

  return (
    <FleetHubPageShell active="/operator/fleet-hubs/drones">
      <OperatorPanel className="flush-panel">
        <div className="toolbar">
          <div className="filter-search"><Icon name="search" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search drones…" /></div>
          <DropdownSelect value={hubFilter} options={[{ value: 'All hubs', label: 'All hubs' }, ...operatorHubs.map((hub) => ({ value: hub.id, label: hub.name }))]} onChange={setHubFilter} ariaLabel="Hub" />
          <DropdownSelect value={technicalFilter} options={['All technical', 'Available', 'Maintenance', 'Battery Replacement']} onChange={setTechnicalFilter} ariaLabel="Technical status" />
          <span className="toolbar-spacer" /><small>{filtered.length} drones</small>
        </div>
        <DroneAvailabilityTable drones={filtered} hubs={operatorHubs} />
      </OperatorPanel>
      <p className="section-note">Technical status is synchronized from Technician fleet data. Current mission assignment is checked separately when planning a mission, so a technically available drone cannot be double-assigned.</p>
    </FleetHubPageShell>
  );
}
