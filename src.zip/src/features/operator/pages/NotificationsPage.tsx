import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ActionButton } from '../../../components/ui/ActionButton';
import { Switch } from '../../../components/ui/Switch';
import { OperatorPanel } from '../components/OperatorPanel';
import { PageHeader } from '../components/PageHeader';
import type { Tone } from '../types/operator';
import { formatDeliveryWindow, getOrderPlanningBadge, getPickupState, isActionablePlanningState } from '../utils/deliveryPlanning';
import { loadOperatorMissions } from '../utils/operatorMissionStorage';
import { loadOperatorOrders } from '../utils/operatorOrderStorage';

export function NotificationsPage() {
  const navigate = useNavigate();
  const orders = useMemo(() => loadOperatorOrders(), []);
  const missions = useMemo(() => loadOperatorMissions(), []);

  const planningOrder = orders.find((order) => isActionablePlanningState(getOrderPlanningBadge(order, missions)));
  const graceOrder = orders.find((order) => getPickupState(order) === 'Grace Period');
  const returnMission = missions.find((mission) => mission.type === 'Return' && mission.status === 'Scheduled');

  const initial = useMemo(() => {
    const values: Array<{ title: string; body: string; time: string; tone: Tone; category: string; read: boolean; target?: string }> = [];
    if (planningOrder) values.push({ title: `${planningOrder.id} is ready for mission planning`, body: `Estimated delivery ${formatDeliveryWindow(planningOrder)}. Create the Mission now; no drone was held when the Order was placed.`, time: 'Now', tone: 'warning', category: 'Planning', read: false, target: `/operator/orders/${planningOrder.id}` });
    if (graceOrder) values.push({ title: `${graceOrder.id} pickup deadline passed`, body: 'Customer is inside the grace period. Package remains physically in the station locker; send the final follow-up before return processing.', time: 'Now', tone: 'warning', category: 'Pickup', read: false, target: `/operator/orders/${graceOrder.id}` });
    if (returnMission) values.push({ title: `${returnMission.id} return Mission created`, body: `System created a return for ${returnMission.orderId}. Review the suggested drone and dispatch when ready.`, time: 'Now', tone: 'danger', category: 'Return', read: false, target: `/operator/missions/${returnMission.id}` });
    values.push(
      { title: 'Mission incident requires monitoring', body: 'MSN-3110 is continuing with a replacement drone. AI/telemetry monitoring remains advisory.', time: '2 min ago', tone: 'warning', category: 'Operational', read: false, target: '/operator/missions/MSN-3110' },
      { title: 'Station capacity remains available', body: 'ST-05 still has capacity after reserved and occupied slots are counted.', time: '24 min ago', tone: 'success', category: 'Station', read: true, target: '/operator/fleet-hubs/stations' },
      { title: 'Telemetry log validated', body: 'Flight log FLT-9179 passed all quality checks.', time: '1 hour ago', tone: 'success', category: 'System', read: true },
    );
    return values;
  }, [graceOrder, planningOrder, returnMission]);

  const [items, setItems] = useState(initial);
  const [filter, setFilter] = useState('All');
  const visibleItems = filter === 'All' ? items : items.filter((item) => item.category === filter);

  return (
    <>
      <PageHeader section="notifications" action={<ActionButton variant="secondary" onClick={() => setItems(items.map((item) => ({ ...item, read: true })))}>Mark all as read</ActionButton>} />
      <div className="notification-layout">
        <OperatorPanel className="flush-panel">
          <div className="notification-filter">
            {['All', 'Planning', 'Pickup', 'Return', 'Operational', 'Station', 'System'].map((item) => (
              <button type="button" className={filter === item ? 'active' : ''} onClick={() => setFilter(item)} key={item}>{item}{item === 'All' && <span>{items.length}</span>}</button>
            ))}
          </div>
          <div className="notification-list">
            {visibleItems.map((item) => {
              const index = items.indexOf(item);
              return (
                <button
                  type="button"
                  className={`${!item.read ? 'unread' : ''} tone-${item.tone}`}
                  key={`${item.category}-${item.title}`}
                  onClick={() => {
                    setItems(items.map((entry, itemIndex) => itemIndex === index ? { ...entry, read: true } : entry));
                    if (item.target) navigate(item.target);
                  }}
                >
                  <span><strong>{item.title}</strong><p>{item.body}</p><small>{item.category} · {item.time}</small></span>
                  {!item.read && <i />}
                </button>
              );
            })}
          </div>
        </OperatorPanel>

        <OperatorPanel title="Notification settings">
          <div className="toggle-row"><span><strong>Critical alerts</strong><small>Airspace, energy, and safety events</small></span><Switch aria-label="Critical alerts" defaultChecked /></div>
          <div className="toggle-row"><span><strong>Planning updates</strong><small>Ready-for-planning and overdue Order reminders</small></span><Switch aria-label="Planning updates" defaultChecked /></div>
          <div className="toggle-row"><span><strong>Pickup exceptions</strong><small>Deadline, grace period, and return-required alerts</small></span><Switch aria-label="Pickup exceptions" defaultChecked /></div>
          <div className="toggle-row"><span><strong>Return dispatch</strong><small>System-created Return Missions waiting for Operator dispatch</small></span><Switch aria-label="Return dispatch" defaultChecked /></div>
        </OperatorPanel>
      </div>
    </>
  );
}
