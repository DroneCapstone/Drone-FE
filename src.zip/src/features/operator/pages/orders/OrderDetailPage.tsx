import { useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ActionButton } from '../../../../components/ui/ActionButton';
import { StatusBadge } from '../../../../components/ui/StatusBadge';
import { OperatorPanel } from '../../components/OperatorPanel';
import {
  formatDeliveryWindow,
  getDeliveryMission,
  getOrderPlanningBadge,
  getPickupState,
  getReturnMission,
  isActionablePlanningState,
} from '../../utils/deliveryPlanning';
import { formatMissionTime } from '../../utils/missionTiming';
import { loadOperatorMissions } from '../../utils/operatorMissionStorage';
import { getOperatorOrder } from '../../utils/operatorOrderStorage';
import { getStation } from '../../utils/stationCapacity';
import { OrderPageShell } from './OrderPageShell';

function money(value = 0) {
  return new Intl.NumberFormat('vi-VN').format(value) + ' ₫';
}

export function OrderDetailPage() {
  const { orderId = '' } = useParams();
  const navigate = useNavigate();
  const order = useMemo(() => getOperatorOrder(orderId), [orderId]);
  const missions = useMemo(() => loadOperatorMissions(), []);

  if (!order) {
    return <OrderPageShell active="/operator/orders/all"><OperatorPanel><div className="operator-empty-state">Order not found.</div></OperatorPanel></OrderPageShell>;
  }

  const deliveryMission = getDeliveryMission(order.id, missions);
  const returnMission = getReturnMission(order.id, missions);
  const planning = getOrderPlanningBadge(order, missions);
  const pickupState = getPickupState(order);
  const pickup = getStation(order.pickupStationId);
  const destination = getStation(order.destinationStationId);
  const actionable = isActionablePlanningState(planning);

  const statusTone = order.status === 'Completed'
    ? 'success'
    : order.status === 'Cancelled'
      ? 'danger'
      : order.status === 'Returned'
        ? 'warning'
        : 'info';

  return (
    <OrderPageShell active="/operator/orders/all">
      <div className="detail-layout">
        <div className="detail-main">
          <OperatorPanel>
            <div className="mission-hero">
              <div>
                <StatusBadge tone={statusTone}>{order.status}</StatusBadge>
                <h2>{order.id}</h2>
                <p>{order.customerName} · {order.packageLabel}</p>
              </div>
              <div className="mission-hero-actions">
                {returnMission && <ActionButton onClick={() => navigate(`/operator/missions/${returnMission.id}`)}>View return mission</ActionButton>}
                {!returnMission && deliveryMission && <ActionButton onClick={() => navigate(`/operator/missions/${deliveryMission.id}`)}>View delivery mission</ActionButton>}
                {!deliveryMission && order.status === 'Pending' && <ActionButton disabled={!actionable} onClick={() => navigate(`/operator/missions/create?orderId=${order.id}`)}>Create mission</ActionButton>}
              </div>
            </div>
          </OperatorPanel>

          <OperatorPanel title="Delivery request" eyebrow="CUSTOMER ORDER">
            <dl className="review-values">
              <div><dt>Pickup station</dt><dd>{pickup?.name ?? order.pickupStationId}</dd></div>
              <div><dt>Destination station</dt><dd>{destination?.name ?? order.destinationStationId}</dd></div>
              <div><dt>Package</dt><dd>{order.packageLabel}</dd></div>
              <div><dt>Package type</dt><dd>{order.packageType}</dd></div>
              <div><dt>Payload</dt><dd>{order.payloadKg} kg</dd></div>
              <div><dt>Estimated delivery</dt><dd>{formatDeliveryWindow(order)}</dd></div>
              <div><dt>Planning opens</dt><dd>{formatMissionTime(order.planningAt)}</dd></div>
              <div><dt>Planning state</dt><dd>{planning ?? (deliveryMission ? 'Mission already created' : 'Closed')}</dd></div>
            </dl>
          </OperatorPanel>

          <OperatorPanel title="Flight Missions" eyebrow="ORDER 1 → N MISSIONS">
            {!deliveryMission && !returnMission ? (
              <div className="linked-record">
                <div><strong>{planning ?? 'No mission required'}</strong><small>{actionable ? 'Planning is open for this Order.' : 'The system will surface this Order when planning opens.'}</small></div>
                {planning && <StatusBadge tone={planning === 'Planning Overdue' ? 'danger' : planning === 'Ready for Planning' ? 'warning' : 'neutral'}>{planning}</StatusBadge>}
                {actionable && <button className="row-action" type="button" onClick={() => navigate(`/operator/missions/create?orderId=${order.id}`)}>Create mission</button>}
              </div>
            ) : (
              <div className="linked-mission-list">
                {deliveryMission && (
                  <button type="button" onClick={() => navigate(`/operator/missions/${deliveryMission.id}`)}>
                    <span><small>DELIVERY</small><strong>{deliveryMission.id}</strong><em>{deliveryMission.drone} · {deliveryMission.route}</em></span>
                    <StatusBadge tone={deliveryMission.tone}>{deliveryMission.status}</StatusBadge>
                  </button>
                )}
                {returnMission && (
                  <button type="button" onClick={() => navigate(`/operator/missions/${returnMission.id}`)}>
                    <span><small>RETURN</small><strong>{returnMission.id}</strong><em>{returnMission.drone} · Destination {returnMission.hubId}</em></span>
                    <StatusBadge tone={returnMission.tone}>{returnMission.status}</StatusBadge>
                  </button>
                )}
              </div>
            )}
          </OperatorPanel>

          {(order.status === 'Ready for Pickup' || order.status === 'Returned') && (
            <OperatorPanel title="Pickup & return policy" eyebrow="PACKAGE HANDOFF">
              <dl className="review-values">
                <div><dt>Pickup state</dt><dd>{pickupState ?? order.returnStatus ?? 'Closed'}</dd></div>
                <div><dt>Ready for pickup</dt><dd>{order.readyForPickupAt ? formatMissionTime(order.readyForPickupAt) : '—'}</dd></div>
                <div><dt>Pickup deadline</dt><dd>{order.pickupDeadline ? formatMissionTime(order.pickupDeadline) : '—'}</dd></div>
                <div><dt>Grace period ends</dt><dd>{order.gracePeriodEndsAt ? formatMissionTime(order.gracePeriodEndsAt) : '—'}</dd></div>
                <div><dt>Return status</dt><dd>{order.returnStatus ?? 'None'}</dd></div>
                <div><dt>Return reason</dt><dd>{order.returnReason ?? '—'}</dd></div>
                <div><dt>Package disposition</dt><dd>{order.packageDisposition ?? 'Still at station'}</dd></div>
                <div><dt>Returned at</dt><dd>{order.returnedAt ? formatMissionTime(order.returnedAt) : '—'}</dd></div>
              </dl>
              <div className="notification-policy-note">
                <strong>Customer notification policy</strong>
                <span>App notification → reminder → final reminder before deadline. SMS / automated call are integration channels when enabled.</span>
              </div>
            </OperatorPanel>
          )}
        </div>

        <aside className="detail-side">
          <OperatorPanel title="Customer">
            <dl className="key-values"><div><dt>Name</dt><dd>{order.customerName}</dd></div><div><dt>Phone</dt><dd>{order.customerPhone}</dd></div><div><dt>Requested date</dt><dd>{order.requestedDate}</dd></div></dl>
            {(pickupState === 'Grace Period' || pickupState === 'Due Soon') && <ActionButton variant="secondary" style={{ width: '100%', marginTop: 12 }}>Contact customer</ActionButton>}
          </OperatorPanel>

          {order.charges && (
            <OperatorPanel title="Charges & responsibility">
              <dl className="key-values">
                <div><dt>Delivery fee</dt><dd>{money(order.charges.deliveryFee)}</dd></div>
                <div><dt>Return fee</dt><dd>{order.charges.returnFee ? money(order.charges.returnFee) : '—'}</dd></div>
                <div><dt>Penalty fee</dt><dd>{order.charges.penaltyFee ? money(order.charges.penaltyFee) : '—'}</dd></div>
                <div><dt>Refund</dt><dd>{order.charges.refundAmount ? money(order.charges.refundAmount) : '—'}</dd></div>
              </dl>
              {order.returnReason === 'Customer Pickup Timeout' && <p className="section-note">Mock business rule: customer-caused no-show can retain the original delivery fee and add return transport cost.</p>}
            </OperatorPanel>
          )}
        </aside>
      </div>
    </OrderPageShell>
  );
}
