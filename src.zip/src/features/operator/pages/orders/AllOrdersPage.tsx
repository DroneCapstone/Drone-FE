import { useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { DropdownSelect } from '../../../../components/ui/DropdownSelect';
import { Icon } from '../../../../components/ui/Icon';
import { OperatorPanel } from '../../components/OperatorPanel';
import { OrderTable } from '../../components/OrderTable';
import { getOrderPlanningBadge, isActionablePlanningState, sortOrdersByPlanningPriority } from '../../utils/deliveryPlanning';
import { loadOperatorMissions } from '../../utils/operatorMissionStorage';
import { loadOperatorOrders } from '../../utils/operatorOrderStorage';
import { OrderPageShell } from './OrderPageShell';

export function AllOrdersPage() {
  const location = useLocation();
  const readyOnly = location.pathname.endsWith('/ready');
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('All statuses');
  const orders = useMemo(() => loadOperatorOrders(), []);
  const missions = useMemo(() => loadOperatorMissions(), []);

  const filtered = sortOrdersByPlanningPriority(orders, missions).filter((order) => {
    const matchesQuery = `${order.id} ${order.customerName} ${order.packageLabel} ${order.pickupStationId} ${order.destinationStationId}`
      .toLowerCase()
      .includes(query.toLowerCase());
    const matchesStatus = status === 'All statuses' || order.status === status;
    const matchesReady = !readyOnly || isActionablePlanningState(getOrderPlanningBadge(order, missions));
    return matchesQuery && matchesStatus && matchesReady;
  });

  return (
    <OrderPageShell active={readyOnly ? '/operator/orders/ready' : '/operator/orders/all'}>
      <OperatorPanel className="flush-panel">
        <div className="toolbar">
          <div className="filter-search"><Icon name="search" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search orders…" /></div>
          <DropdownSelect
            value={status}
            options={['All statuses', 'Pending', 'Ready for Pickup', 'Completed', 'Returned', 'Cancelled']}
            onChange={setStatus}
            ariaLabel="Order status"
          />
          <span className="toolbar-spacer" />
          <small>{filtered.length} orders</small>
        </div>
        <OrderTable orders={filtered} missions={missions} />
      </OperatorPanel>
    </OrderPageShell>
  );
}
