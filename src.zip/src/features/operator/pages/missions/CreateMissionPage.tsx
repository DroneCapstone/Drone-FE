import { useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';

import { ActionButton } from '../../../../components/ui/ActionButton';
import { Icon } from '../../../../components/ui/Icon';
import { StatusBadge } from '../../../../components/ui/StatusBadge';

import { EligibleDroneCard } from '../../components/EligibleDroneCard';
import { EnergyPredictionSummary } from '../../components/EnergyPredictionSummary';
import { HubCard } from '../../components/HubCard';
import { OperatorPanel } from '../../components/OperatorPanel';
import { RouteOptionCard } from '../../components/RouteOptionCard';
import { operatorHubs, mockPickupDistanceKm } from '../../data/hubMockData';
import { routeOptions } from '../../data/routeMockData';
import type { Mission, OperatorDrone } from '../../types/operator';
import { formatDeliveryWindow, getOrderPlanningBadge, isActionablePlanningState } from '../../utils/deliveryPlanning';
import { getBasicDroneEligibility, getEnergyFeasibility } from '../../utils/droneEligibility';
import { clearMissionDraft, loadMissionDraft, saveMissionDraft } from '../../utils/missionDraftStorage';
import { calculateRouteTiming, formatMissionTime } from '../../utils/missionTiming';
import { loadOperatorFleet } from '../../utils/operatorFleetStorage';
import { loadOperatorMissions, prependMission } from '../../utils/operatorMissionStorage';
import { loadOperatorOrders } from '../../utils/operatorOrderStorage';
import { getAvailableSlotCount, getStation, reserveStationSlot } from '../../utils/stationCapacity';

import { MissionPageShell } from './MissionPageShell';

const STEPS = ['Order info', 'Hub & drone', 'Route, energy & timing', 'Review & assign'] as const;

export function CreateMissionPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('orderId') ?? '';

  const orders = useMemo(() => loadOperatorOrders(), []);
  const missions = useMemo(() => loadOperatorMissions(), []);
  const fleet = useMemo(() => loadOperatorFleet(), []);
  const order = orders.find((item) => item.id === orderId);
  const restoredDraft = useMemo(() => (orderId ? loadMissionDraft(orderId) : undefined), [orderId]);
  const existingMission = order ? missions.find((mission) => mission.orderId === order.id && mission.type === 'Delivery') : undefined;

  const [step, setStep] = useState(restoredDraft?.step ?? 1);
  const [toast, setToast] = useState('');
  const [selectedHubId, setSelectedHubId] = useState(restoredDraft?.selectedHubId || 'HUB-HCM-02');
  const [selectedDroneId, setSelectedDroneId] = useState(restoredDraft?.selectedDroneId || '');
  const [selectedRouteId, setSelectedRouteId] = useState(restoredDraft?.selectedRouteId || '');

  if (!order) {
    return (
      <MissionPageShell active="/operator/missions/all">
        <OperatorPanel title="Create a mission from an order" eyebrow="DELIVERY OPERATIONS">
          <div className="operator-empty-state mission-create-gate">
            Flight Missions cannot be created as standalone records. Open an order when its planning window is ready, then choose <strong>Create mission</strong>.
            <ActionButton onClick={() => navigate('/operator/orders/ready')}>View ready orders</ActionButton>
          </div>
        </OperatorPanel>
      </MissionPageShell>
    );
  }

  if (existingMission) {
    return (
      <MissionPageShell active="/operator/missions/all">
        <OperatorPanel title="Delivery Mission already exists" eyebrow={order.id}>
          <div className="linked-record">
            <div><strong>{existingMission.id}</strong><small>{existingMission.drone} · {existingMission.route}</small></div>
            <StatusBadge tone={existingMission.tone}>{existingMission.status}</StatusBadge>
            <button type="button" className="row-action" onClick={() => navigate(`/operator/missions/${existingMission.id}`)}>View mission</button>
          </div>
        </OperatorPanel>
      </MissionPageShell>
    );
  }

  const planningState = getOrderPlanningBadge(order, missions);
  const selectedHub = operatorHubs.find((hub) => hub.id === selectedHubId);
  const selectedDrone = fleet.find((drone) => drone.id === selectedDroneId);
  const selectedRoute = routeOptions.find((route) => route.id === selectedRouteId);
  const originStation = getStation(order.pickupStationId);
  const destinationStation = getStation(order.destinationStationId);
  const hubCandidates = [...operatorHubs].sort((a, b) => mockPickupDistanceKm[a.id] - mockPickupDistanceKm[b.id]);
  const dronesAtSelectedHub = fleet.filter((drone) => drone.hubId === selectedHubId);
  const hubReadyCount = (hubId: string) => fleet.filter((drone) => getBasicDroneEligibility(drone, hubId, order.payloadKg, missions).eligible).length;
  const destinationCapacity = getAvailableSlotCount(order.destinationStationId);
  const selectedTiming = selectedRoute ? calculateRouteTiming(order, selectedRoute) : undefined;

  const canContinueStep1 = isActionablePlanningState(planningState);
  const canContinueStep2 = Boolean(selectedHub && selectedDrone);
  const canContinueStep3 = Boolean(selectedRoute && selectedDrone && selectedTiming);

  const handleHubSelect = (hubId: string) => {
    setSelectedHubId(hubId);
    setSelectedDroneId('');
    setSelectedRouteId('');
  };

  const handleDroneSelect = (drone: OperatorDrone) => {
    setSelectedDroneId(drone.id);
    setSelectedRouteId('');
  };

  const showToast = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(''), 2600);
  };

  const persistDraft = (nextStep = step, routeId = selectedRouteId) => {
    saveMissionDraft({
      orderId: order.id,
      step: nextStep,
      selectedHubId,
      selectedDroneId,
      selectedRouteId: routeId,
    });
  };

  const handleViewAiDetails = (routeId: string) => {
    persistDraft(3, selectedRouteId);
    navigate(`/operator/ai/mission-analysis?orderId=${order.id}&droneId=${selectedDroneId}&routeId=${routeId}&returnTo=mission-create`);
  };

  const handleAssignMission = () => {
    if (!selectedHub || !selectedDrone || !selectedRoute || !selectedTiming) return;

    const energy = getEnergyFeasibility(selectedDrone, selectedRoute);
    if (!energy.feasible) {
      showToast('Selected route does not keep the minimum battery reserve');
      return;
    }

    if (getAvailableSlotCount(order.destinationStationId) <= 0) {
      showToast('Destination station has no available slot');
      return;
    }

    const missionId = `MSN-${String(Date.now()).slice(-6)}`;
    const destinationSlotId = reserveStationSlot(order.destinationStationId, order.id, missionId);
    if (!destinationSlotId) {
      showToast('Unable to reserve a destination station slot');
      return;
    }

    const mission: Mission = {
      id: missionId,
      orderId: order.id,
      type: 'Delivery',
      name: `Delivery ${order.id}`,
      droneId: selectedDrone.id,
      drone: selectedDrone.name,
      hubId: selectedHub.id,
      routeId: selectedRoute.id,
      route: `${selectedRoute.id} ${selectedRoute.name}`,
      status: 'Scheduled',
      tone: 'info',
      eta: selectedTiming.estimatedArrivalAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      battery: energy.remainingBattery,
      plannedStartAt: selectedTiming.plannedStartAt.toISOString(),
      estimatedArrivalAt: selectedTiming.estimatedArrivalAt.toISOString(),
      predictedDurationMin: selectedRoute.predictedDurationMin,
      estimatedEnergyWh: selectedRoute.predictedEnergyWh,
      batteryConsumptionPct: selectedRoute.batteryConsumptionPct,
      confidencePct: selectedRoute.confidencePct,
      risk: selectedRoute.risk,
      destinationSlotId,
      createdAt: new Date().toISOString(),
    };

    prependMission(mission);
    clearMissionDraft(order.id);
    showToast('Mission assigned successfully');
    window.setTimeout(() => navigate(`/operator/missions/${missionId}`), 500);
  };

  return (
    <MissionPageShell active="/operator/missions/all">
      <div className="mission-builder">
        <div className="mission-builder-steps" aria-label="Mission creation steps">
          {STEPS.map((label, index) => {
            const number = index + 1;
            const active = number === step;
            const done = number < step;
            return (
              <button
                key={label}
                type="button"
                className={`${active ? 'active' : ''} ${done ? 'done' : ''}`}
                onClick={() => done && setStep(number)}
                disabled={!done && !active}
              >
                <i>{done ? <Icon name="check" size={12} /> : number}</i><span>{label}</span>
              </button>
            );
          })}
        </div>

        {step === 1 && (
          <OperatorPanel title="Order information" eyebrow="STEP 01 · READ ONLY">
            <div className="fields two">
              <label><span>Order</span><input value={order.id} readOnly /></label>
              <label><span>Customer</span><input value={order.customerName} readOnly /></label>
              <label><span>Pickup station</span><input value={originStation?.name ?? order.pickupStationId} readOnly /></label>
              <label><span>Destination station</span><input value={destinationStation?.name ?? order.destinationStationId} readOnly /></label>
              <label><span>Package</span><input value={`${order.packageLabel} · ${order.payloadKg} kg`} readOnly /></label>
              <label><span>Estimated delivery</span><input value={formatDeliveryWindow(order)} readOnly /></label>
            </div>
            <div className="mission-planning-note">
              <StatusBadge tone={canContinueStep1 ? 'warning' : 'neutral'}>{planningState ?? 'Mission already planned'}</StatusBadge>
              <span>{canContinueStep1 ? 'Planning is open. No drone was reserved when the customer placed the order.' : `Planning opens ${formatMissionTime(order.planningAt)}.`}</span>
            </div>
          </OperatorPanel>
        )}

        {step === 2 && (
          <div className="mission-step-stack">
            <OperatorPanel title="Choose dispatch hub" eyebrow="STEP 02 · HUB">
              <div className="hub-grid hub-grid-select">
                {hubCandidates.map((hub) => (
                  <HubCard
                    key={hub.id}
                    hub={hub}
                    totalDrones={fleet.filter((drone) => drone.hubId === hub.id).length}
                    readyDrones={hubReadyCount(hub.id)}
                    distanceKm={mockPickupDistanceKm[hub.id]}
                    selected={hub.id === selectedHubId}
                    onSelect={() => handleHubSelect(hub.id)}
                  />
                ))}
              </div>
            </OperatorPanel>

            <OperatorPanel title="Choose drone" eyebrow="STEP 02 · TECHNICAL + ASSIGNMENT CHECK">
              <p className="section-note">Technical status comes from Technician. A technically Available drone is still blocked here if it already has a Scheduled or In Progress mission.</p>
              <div className="eligible-drone-grid">
                {dronesAtSelectedHub.map((drone) => {
                  const eligibility = getBasicDroneEligibility(drone, selectedHubId, order.payloadKg, missions);
                  return <EligibleDroneCard key={drone.id} drone={drone} eligibility={eligibility} selected={drone.id === selectedDroneId} onSelect={() => handleDroneSelect(drone)} />;
                })}
              </div>
              {dronesAtSelectedHub.length === 0 && <div className="operator-empty-state">No drones are registered at this hub.</div>}
            </OperatorPanel>
          </div>
        )}

        {step === 3 && selectedDrone && (
          <div className="mission-step-stack">
            <OperatorPanel title="Route, energy & timing" eyebrow="STEP 03 · AI-ASSISTED DECISION">
              <div className="ai-inline-note">
                <Icon name="spark" size={17} />
                <span><strong>AI calculates timing automatically.</strong> Operator compares the route summary and only opens AI Details when deeper analysis is needed.</span>
              </div>
              <div className="route-option-list">
                {routeOptions.map((route) => {
                  const energy = getEnergyFeasibility(selectedDrone, route);
                  const timing = calculateRouteTiming(order, route);
                  return (
                    <RouteOptionCard
                      key={route.id}
                      route={route}
                      remainingBattery={energy.remainingBattery}
                      feasible={energy.feasible}
                      plannedStartAt={timing.plannedStartAt}
                      estimatedArrivalAt={timing.estimatedArrivalAt}
                      selected={route.id === selectedRouteId}
                      onSelect={() => setSelectedRouteId(route.id)}
                      onViewDetails={() => handleViewAiDetails(route.id)}
                    />
                  );
                })}
              </div>
            </OperatorPanel>

            {selectedRoute && selectedTiming && (
              <OperatorPanel title="Selected route summary" eyebrow="AI PREDICTED OUTCOME">
                <EnergyPredictionSummary
                  drone={selectedDrone}
                  route={selectedRoute}
                  plannedStartAt={selectedTiming.plannedStartAt}
                  estimatedArrivalAt={selectedTiming.estimatedArrivalAt}
                />
              </OperatorPanel>
            )}
          </div>
        )}

        {step === 3 && !selectedDrone && (
          <OperatorPanel title="Route, energy & timing" eyebrow="STEP 03">
            <div className="operator-empty-state">Choose an eligible drone in Step 2 before AI compares route, energy, and timing.</div>
          </OperatorPanel>
        )}

        {step === 4 && selectedHub && selectedDrone && selectedRoute && selectedTiming && (
          <OperatorPanel title="Review & assign" eyebrow="STEP 04">
            <div className="mission-review-grid">
              <dl className="review-values">
                <div><dt>Order</dt><dd>{order.id}</dd></div><div><dt>Type</dt><dd>Delivery</dd></div>
                <div><dt>Pickup</dt><dd>{originStation?.name ?? order.pickupStationId}</dd></div><div><dt>Destination</dt><dd>{destinationStation?.name ?? order.destinationStationId}</dd></div>
                <div><dt>Hub</dt><dd>{selectedHub.name}</dd></div><div><dt>Drone</dt><dd>{selectedDrone.name}</dd></div>
                <div><dt>Route</dt><dd>{selectedRoute.id} · {selectedRoute.name}</dd></div><div><dt>Predicted duration</dt><dd>{selectedRoute.predictedDurationMin} min</dd></div>
                <div><dt>Planned start</dt><dd>{formatMissionTime(selectedTiming.plannedStartAt)}</dd></div><div><dt>Estimated arrival</dt><dd>{formatMissionTime(selectedTiming.estimatedArrivalAt)}</dd></div>
              </dl>
              <div className="mission-review-side">
                <div className="review-readiness">
                  <StatusBadge tone={destinationCapacity > 0 ? 'success' : 'danger'}>{destinationCapacity > 0 ? 'Station slot available' : 'Station full'}</StatusBadge>
                  <small>{destinationCapacity} destination slot(s) currently available. One slot is reserved only after Assign Mission succeeds.</small>
                </div>
                <EnergyPredictionSummary drone={selectedDrone} route={selectedRoute} plannedStartAt={selectedTiming.plannedStartAt} estimatedArrivalAt={selectedTiming.estimatedArrivalAt} />
              </div>
            </div>
          </OperatorPanel>
        )}

        <div className="form-actions mission-builder-actions">
          {step > 1 && <ActionButton variant="secondary" onClick={() => { const next = Math.max(1, step - 1); setStep(next); persistDraft(next); }}>Back</ActionButton>}
          {step === 1 && <ActionButton disabled={!canContinueStep1} onClick={() => { setStep(2); persistDraft(2); }}>Continue</ActionButton>}
          {step === 2 && <ActionButton disabled={!canContinueStep2} onClick={() => { setStep(3); persistDraft(3); }}>Continue</ActionButton>}
          {step === 3 && <ActionButton disabled={!canContinueStep3} onClick={() => { setStep(4); persistDraft(4); }}>Review mission</ActionButton>}
          {step === 4 && <ActionButton icon="check" disabled={destinationCapacity <= 0} onClick={handleAssignMission}>Assign mission</ActionButton>}
        </div>
      </div>
      {toast && <div className="operator-toast">{toast}</div>}
    </MissionPageShell>
  );
}
