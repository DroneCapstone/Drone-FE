export const PICKUP_POLICY = {
  standardWindowMinutes: 5 * 60,
  perishableWindowMinutes: 30,
  dueSoonMinutes: 60,
  gracePeriodMinutes: 15,
} as const;

export function getPickupWindowMinutes(packageType: string) {
  const normalized = packageType.toLowerCase();
  return normalized.includes('food') || normalized.includes('meal') || normalized.includes('perishable')
    ? PICKUP_POLICY.perishableWindowMinutes
    : PICKUP_POLICY.standardWindowMinutes;
}
