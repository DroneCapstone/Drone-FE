import type { Order, RouteOption } from '../types/operator';

export const MISSION_PREPARATION_BUFFER_MINUTES = 5;

export function calculateRouteTiming(order: Order, route: RouteOption) {
  const targetArrivalAt = new Date(order.currentEstimatedWindow.start);
  const plannedStartAt = new Date(
    targetArrivalAt.getTime() - (route.predictedDurationMin + MISSION_PREPARATION_BUFFER_MINUTES) * 60_000,
  );

  return {
    plannedStartAt,
    estimatedArrivalAt: targetArrivalAt,
    preparationBufferMin: MISSION_PREPARATION_BUFFER_MINUTES,
  };
}

export function formatMissionTime(value: string | Date) {
  const date = typeof value === 'string' ? new Date(value) : value;
  return date.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}
