import { missions as defaultMissions } from '../data/mockOperatorData';
import { routeOptions } from '../data/routeMockData';
import type { Mission, MissionStatus, Tone } from '../types/operator';
import { getPickupState } from './deliveryPlanning';
import { loadOperatorFleet } from './operatorFleetStorage';
import { loadOperatorOrders, saveOperatorOrders } from './operatorOrderStorage';

const STORAGE_KEY = 'droneoptai.operator.missions.v3';

export function getMissionTone(status: MissionStatus): Tone {
  if (status === 'Completed') return 'success';
  if (status === 'Failed' || status === 'Cancelled') return 'danger';
  if (status === 'In Progress') return 'success';
  return 'info';
}

function normalizeMission(item: Partial<Mission> & Record<string, unknown>): Mission {
  const rawStatus = String(item.status ?? 'Scheduled');
  let status: MissionStatus = 'Scheduled';
  let scheduleState: Mission['scheduleState'];

  if (rawStatus === 'In flight' || rawStatus === 'In Flight' || rawStatus === 'In Progress') status = 'In Progress';
  else if (rawStatus === 'Completed') status = 'Completed';
  else if (rawStatus === 'Cancelled') status = 'Cancelled';
  else if (rawStatus === 'Failed') status = 'Failed';
  else if (rawStatus === 'Delayed') {
    status = 'In Progress';
    scheduleState = 'Delayed';
  } else if (rawStatus === 'Review') status = 'Scheduled';

  const now = new Date().toISOString();
  const legacyStart = String(item.plannedStartAt ?? item.scheduledDepartureAt ?? now);
  const predictedDurationMin = Number(item.predictedDurationMin ?? 30);
  const estimatedEnergyWh = Number(item.estimatedEnergyWh ?? 0);
  const batteryConsumptionPct = Number(item.batteryConsumptionPct ?? 0);

  return {
    id: String(item.id ?? `MSN-${Date.now()}`),
    orderId: String(item.orderId ?? 'UNLINKED'),
    type: item.type === 'Return' ? 'Return' : 'Delivery',
    name: String(item.name ?? 'Delivery mission'),
    droneId: String(item.droneId ?? ''),
    drone: String(item.drone ?? 'Unassigned'),
    hubId: String(item.hubId ?? ''),
    routeId: String(item.routeId ?? ''),
    route: String(item.route ?? 'Pending route'),
    status,
    tone: getMissionTone(status),
    eta: String(item.eta ?? 'Pending'),
    battery: Number(item.battery ?? 0),
    plannedStartAt: legacyStart,
    actualStartedAt: item.actualStartedAt,
    actualCompletedAt: item.actualCompletedAt,
    estimatedArrivalAt: String(item.estimatedArrivalAt ?? now),
    predictedDurationMin,
    estimatedEnergyWh,
    batteryConsumptionPct,
    confidencePct: item.confidencePct,
    risk: item.risk,
    scheduleState: item.scheduleState ?? scheduleState,
    destinationSlotId: item.destinationSlotId,
    assignmentHistory: Array.isArray(item.assignmentHistory) ? item.assignmentHistory : [],
    createdAt: String(item.createdAt ?? now),
  };
}

function isActive(mission: Mission) {
  return mission.status === 'Scheduled' || mission.status === 'In Progress';
}

function ensureAutomatedReturnMissions(current: Mission[]) {
  if (typeof window === 'undefined') return current;

  const orders = loadOperatorOrders();
  const fleet = loadOperatorFleet();
  let nextMissions = [...current];
  let nextOrders = [...orders];
  let missionsChanged = false;
  let ordersChanged = false;

  orders.forEach((order) => {
    if (order.status !== 'Ready for Pickup' || getPickupState(order) !== 'Return Required') return;
    if (nextMissions.some((mission) => mission.orderId === order.id && mission.type === 'Return')) return;

    const deliveryMission = nextMissions.find((mission) => mission.orderId === order.id && mission.type === 'Delivery');
    const hubId = deliveryMission?.hubId ?? 'HUB-HCM-01';
    const drone = fleet.find((candidate) =>
      candidate.hubId === hubId &&
      candidate.technicalStatus === 'Available' &&
      candidate.maxPayloadKg >= order.payloadKg &&
      !nextMissions.some((mission) => mission.droneId === candidate.id && isActive(mission)),
    );

    if (!drone) return;

    const route = routeOptions.find((item) => item.recommended) ?? routeOptions[0];
    const plannedStartAt = new Date(Date.now() + 10 * 60_000);
    const estimatedArrivalAt = new Date(plannedStartAt.getTime() + route.predictedDurationMin * 60_000);
    const missionId = `MSN-R${order.id.replace('ORD-', '')}`;
    const batteryAfter = Math.max(0, drone.battery - route.batteryConsumptionPct);

    nextMissions = [
      {
        id: missionId,
        orderId: order.id,
        type: 'Return',
        name: `Return ${order.id}`,
        droneId: drone.id,
        drone: drone.name,
        hubId,
        routeId: route.id,
        route: `${route.id} ${route.name}`,
        status: 'Scheduled',
        tone: 'info',
        eta: estimatedArrivalAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        battery: batteryAfter,
        plannedStartAt: plannedStartAt.toISOString(),
        estimatedArrivalAt: estimatedArrivalAt.toISOString(),
        predictedDurationMin: route.predictedDurationMin,
        estimatedEnergyWh: Math.max(0, route.predictedEnergyWh - 2.5),
        batteryConsumptionPct: Math.max(1, route.batteryConsumptionPct - 2),
        confidencePct: route.confidencePct,
        risk: route.risk,
        createdAt: new Date().toISOString(),
      },
      ...nextMissions,
    ];
    missionsChanged = true;

    nextOrders = nextOrders.map((item) => item.id === order.id ? {
      ...item,
      returnStatus: 'Return Planned' as const,
      returnReason: item.returnReason ?? 'Customer Pickup Timeout' as const,
      charges: item.charges
        ? { ...item.charges, returnFee: item.charges.returnFee ?? 45000 }
        : { deliveryFee: 65000, returnFee: 45000, currency: 'VND' as const },
    } : item);
    ordersChanged = true;
  });

  if (missionsChanged) localStorage.setItem(STORAGE_KEY, JSON.stringify(nextMissions));
  if (ordersChanged) saveOperatorOrders(nextOrders);
  return nextMissions;
}

export function loadOperatorMissions(): Mission[] {
  if (typeof window === 'undefined') return defaultMissions;
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    const parsed: Array<Partial<Mission> & Record<string, unknown>> = stored
      ? JSON.parse(stored) as Array<Partial<Mission> & Record<string, unknown>>
      : defaultMissions as unknown as Array<Partial<Mission> & Record<string, unknown>>;
    const normalized = Array.isArray(parsed) ? parsed.map(normalizeMission) : defaultMissions;
    return ensureAutomatedReturnMissions(normalized);
  } catch {
    return ensureAutomatedReturnMissions(defaultMissions);
  }
}

export function saveOperatorMissions(items: Mission[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}

export function prependMission(mission: Mission) {
  const current = loadOperatorMissions();
  saveOperatorMissions([mission, ...current.filter((item) => item.id !== mission.id)]);
}

export function updateMission(missionId: string, updates: Partial<Mission>) {
  const current = loadOperatorMissions();
  const next = current.map((mission) => {
    if (mission.id !== missionId) return mission;
    const nextStatus = updates.status ?? mission.status;
    return { ...mission, ...updates, tone: getMissionTone(nextStatus) };
  });
  saveOperatorMissions(next);
  return next.find((mission) => mission.id === missionId);
}

export function updateMissionStatus(missionId: string, status: MissionStatus) {
  return updateMission(missionId, { status });
}

export function hasActiveMissionForDrone(droneId: string, missions = loadOperatorMissions()) {
  return missions.some(
    (mission) => mission.droneId === droneId && isActive(mission),
  );
}

export function reassignMissionDrone(
  missionId: string,
  droneId: string,
  droneName: string,
  reason = 'Replacement required during mission',
) {
  const current = loadOperatorMissions();
  const mission = current.find((item) => item.id === missionId);
  if (!mission) return undefined;

  return updateMission(missionId, {
    assignmentHistory: [
      ...(mission.assignmentHistory ?? []),
      {
        droneId: mission.droneId,
        droneName: mission.drone,
        replacedAt: new Date().toISOString(),
        reason,
      },
    ],
    droneId,
    drone: droneName,
  });
}

export function getMissionForOrder(orderId: string, type: Mission['type'] = 'Delivery') {
  return loadOperatorMissions().find((mission) => mission.orderId === orderId && mission.type === type);
}

export function getMissionsForOrder(orderId: string) {
  return loadOperatorMissions().filter((mission) => mission.orderId === orderId);
}
