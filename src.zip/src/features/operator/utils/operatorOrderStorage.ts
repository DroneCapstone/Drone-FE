import { defaultOrders } from '../data/orderMockData';
import type { Order } from '../types/operator';
import { getPickupWindowMinutes, PICKUP_POLICY } from './pickupPolicy';

const STORAGE_KEY = 'droneoptai.operator.orders.v2';

export function loadOperatorOrders(): Order[] {
  if (typeof window === 'undefined') return defaultOrders;

  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return defaultOrders;
    const parsed = JSON.parse(stored) as Order[];
    return Array.isArray(parsed) ? parsed : defaultOrders;
  } catch {
    return defaultOrders;
  }
}

export function saveOperatorOrders(orders: Order[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(orders));
}

export function getOperatorOrder(orderId: string) {
  return loadOperatorOrders().find((order) => order.id === orderId);
}

export function updateOperatorOrder(orderId: string, updates: Partial<Order>) {
  const orders = loadOperatorOrders();
  const next = orders.map((order) => (order.id === orderId ? { ...order, ...updates } : order));
  saveOperatorOrders(next);
  return next.find((order) => order.id === orderId);
}

export function markOrderReadyForPickup(orderId: string) {
  const order = getOperatorOrder(orderId);
  if (!order) return undefined;

  const readyAt = new Date();
  const pickupWindowMinutes = getPickupWindowMinutes(order.packageType);
  const deadline = new Date(readyAt.getTime() + pickupWindowMinutes * 60_000);
  const graceEnd = new Date(deadline.getTime() + PICKUP_POLICY.gracePeriodMinutes * 60_000);

  return updateOperatorOrder(orderId, {
    status: 'Ready for Pickup',
    readyForPickupAt: readyAt.toISOString(),
    pickupDeadline: deadline.toISOString(),
    gracePeriodEndsAt: graceEnd.toISOString(),
    pickupState: 'Waiting',
    returnStatus: 'None',
  });
}

export function completeOrderPickup(orderId: string) {
  return updateOperatorOrder(orderId, {
    status: 'Completed',
    packageDisposition: 'Delivered',
    pickupState: undefined,
    returnStatus: 'None',
  });
}

export function markOrderReturned(orderId: string) {
  return updateOperatorOrder(orderId, {
    status: 'Returned',
    returnStatus: 'Returned to Hub',
    packageDisposition: 'Returned',
    returnedAt: new Date().toISOString(),
    pickupState: undefined,
  });
}
