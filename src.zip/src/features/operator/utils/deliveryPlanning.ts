import type { Mission, Order, PickupState, PlanningState } from '../types/operator';
import { PICKUP_POLICY } from './pickupPolicy';

export const MISSION_PLANNING_BUFFER_MINUTES = 60;
export const PLANNING_OVERDUE_AFTER_MINUTES = 30;

export function hasDeliveryMission(orderId: string, missions: Mission[]) {
  return missions.some((mission) => mission.orderId === orderId && mission.type === 'Delivery');
}

export function getDeliveryMission(orderId: string, missions: Mission[]) {
  return missions.find((mission) => mission.orderId === orderId && mission.type === 'Delivery');
}

export function getReturnMission(orderId: string, missions: Mission[]) {
  return missions.find((mission) => mission.orderId === orderId && mission.type === 'Return');
}

export function getMissionsForOrder(orderId: string, missions: Mission[]) {
  return missions.filter((mission) => mission.orderId === orderId);
}

export function getPlanningState(
  order: Order,
  missions: Mission[],
  now = new Date(),
): PlanningState {
  const planningAt = new Date(order.planningAt).getTime();
  const nowMs = now.getTime();
  const overdueAt = planningAt + PLANNING_OVERDUE_AFTER_MINUTES * 60_000;

  if (nowMs >= overdueAt) return 'Planning Overdue';
  if (nowMs >= planningAt) return 'Ready for Planning';

  const minutesUntilPlanning = (planningAt - nowMs) / 60_000;
  if (minutesUntilPlanning <= MISSION_PLANNING_BUFFER_MINUTES) return 'Upcoming';
  return 'Future';
}

export function getOrderPlanningBadge(order: Order, missions: Mission[], now = new Date()) {
  if (order.status !== 'Pending' || hasDeliveryMission(order.id, missions)) return undefined;
  return getPlanningState(order, missions, now);
}

export function isActionablePlanningState(state: PlanningState | undefined) {
  return state === 'Planning Overdue' || state === 'Ready for Planning';
}

export function getPlanningPriority(state: PlanningState | undefined) {
  if (!state) return 4;
  return {
    'Planning Overdue': 0,
    'Ready for Planning': 1,
    Upcoming: 2,
    Future: 3,
  }[state];
}

export function sortOrdersByPlanningPriority(orders: Order[], missions: Mission[]) {
  return [...orders].sort((a, b) => {
    const aState = getOrderPlanningBadge(a, missions);
    const bState = getOrderPlanningBadge(b, missions);
    const priority = getPlanningPriority(aState) - getPlanningPriority(bState);
    if (priority !== 0) return priority;
    return new Date(a.planningAt).getTime() - new Date(b.planningAt).getTime();
  });
}

export function getPickupState(order: Order, now = new Date()): PickupState | undefined {
  if (order.status !== 'Ready for Pickup' || !order.pickupDeadline) return undefined;
  if (order.returnStatus === 'Return Planned' || order.returnStatus === 'Returning') return 'Return Required';

  const nowMs = now.getTime();
  const deadline = new Date(order.pickupDeadline).getTime();
  const graceEnd = order.gracePeriodEndsAt
    ? new Date(order.gracePeriodEndsAt).getTime()
    : deadline + PICKUP_POLICY.gracePeriodMinutes * 60_000;

  if (nowMs >= graceEnd) return 'Return Required';
  if (nowMs >= deadline) return 'Grace Period';
  if (deadline - nowMs <= PICKUP_POLICY.dueSoonMinutes * 60_000) return 'Due Soon';
  return 'Waiting';
}

export function formatDeliveryWindow(order: Order) {
  const start = new Date(order.currentEstimatedWindow.start);
  const end = new Date(order.currentEstimatedWindow.end);
  const sameDay = start.toDateString() === new Date().toDateString();
  const day = sameDay
    ? 'Today'
    : start.toLocaleDateString([], { month: 'short', day: 'numeric' });
  const time = `${start.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}–${end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  return `${day} · ${time}`;
}
