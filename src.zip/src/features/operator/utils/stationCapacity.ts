import { defaultStations } from '../data/stationMockData';
import type { LockerSlot, Station } from '../types/operator';

const STORAGE_KEY = 'droneoptai.operator.stations.v2';

export function loadStations(): Station[] {
  if (typeof window === 'undefined') return defaultStations;

  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return defaultStations;
    const parsed = JSON.parse(stored) as Station[];
    return Array.isArray(parsed) ? parsed : defaultStations;
  } catch {
    return defaultStations;
  }
}

export function saveStations(stations: Station[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(stations));
}

export function getStation(stationId: string) {
  return loadStations().find((station) => station.id === stationId);
}

export function getStationCounts(station: Station) {
  const count = (status: LockerSlot['status']) => station.slots.filter((slot) => slot.status === status).length;
  return {
    total: station.slots.length,
    available: count('Available'),
    reserved: count('Reserved'),
    occupied: count('Occupied'),
    outOfService: count('Out of Service'),
  };
}

export function getAvailableSlotCount(stationId: string) {
  const station = getStation(stationId);
  return station ? getStationCounts(station).available : 0;
}

export function reserveStationSlot(stationId: string, orderId: string, missionId: string) {
  const stations = loadStations();
  let reservedSlotId: string | undefined;

  const next = stations.map((station) => {
    if (station.id !== stationId || station.status !== 'Active') return station;
    const available = station.slots.find((slot) => slot.status === 'Available');
    if (!available) return station;
    reservedSlotId = available.id;
    return {
      ...station,
      slots: station.slots.map((slot) =>
        slot.id === available.id
          ? { ...slot, status: 'Reserved' as const, orderId, missionId }
          : slot,
      ),
    };
  });

  if (reservedSlotId) saveStations(next);
  return reservedSlotId;
}

export function occupyReservedStationSlot(stationId: string, orderId: string, missionId: string) {
  const stations = loadStations();
  let occupiedSlotId: string | undefined;
  const next = stations.map((station) => {
    if (station.id !== stationId) return station;
    return {
      ...station,
      slots: station.slots.map((slot) => {
        if (slot.orderId === orderId && slot.missionId === missionId && slot.status === 'Reserved') {
          occupiedSlotId = slot.id;
          return { ...slot, status: 'Occupied' as const };
        }
        return slot;
      }),
    };
  });
  if (occupiedSlotId) saveStations(next);
  return occupiedSlotId;
}

export function releaseOrderStationSlot(orderId: string) {
  const stations = loadStations();
  let released = false;
  const next = stations.map((station) => ({
    ...station,
    slots: station.slots.map((slot) => {
      if (slot.orderId !== orderId || (slot.status !== 'Occupied' && slot.status !== 'Reserved')) return slot;
      released = true;
      return { id: slot.id, stationId: slot.stationId, status: 'Available' as const };
    }),
  }));
  if (released) saveStations(next);
  return released;
}
