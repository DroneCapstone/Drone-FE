import type { OperatorDrone } from '../types/operator';

export const operatorDrones: OperatorDrone[] = [
  { id: 'DR-001', name: 'CX-09', model: 'DJI Matrice 350', hubId: 'HUB-HCM-02', technicalStatus: 'Available', battery: 86, maxPayloadKg: 8 },
  { id: 'DR-002', name: 'CX-12', model: 'DJI Matrice 350', hubId: 'HUB-HCM-02', technicalStatus: 'Available', battery: 64, maxPayloadKg: 8 },
  { id: 'DR-003', name: 'AX-04', model: 'DJI FlyCart 30', hubId: 'HUB-HCM-02', technicalStatus: 'Maintenance', battery: 92, maxPayloadKg: 12 },
  { id: 'DR-004', name: 'AX-17', model: 'DJI FlyCart 30', hubId: 'HUB-HCM-01', technicalStatus: 'Available', battery: 96, maxPayloadKg: 12 },
  { id: 'DR-005', name: 'NX-08', model: 'DJI Matrice 350', hubId: 'HUB-HCM-01', technicalStatus: 'Available', battery: 78, maxPayloadKg: 8 },
  { id: 'DR-006', name: 'MX-22', model: 'DJI Matrice 300', hubId: 'HUB-HCM-01', technicalStatus: 'Available', battery: 48, maxPayloadKg: 6 },
  { id: 'DR-007', name: 'CX-21', model: 'DJI Matrice 350', hubId: 'HUB-HCM-03', technicalStatus: 'Available', battery: 81, maxPayloadKg: 8 },
  { id: 'DR-008', name: 'AX-26', model: 'DJI FlyCart 30', hubId: 'HUB-HCM-03', technicalStatus: 'Available', battery: 73, maxPayloadKg: 12 },
  { id: 'DR-009', name: 'CX-31', model: 'DJI Matrice 350', hubId: 'HUB-HCM-03', technicalStatus: 'Battery Replacement', battery: 88, maxPayloadKg: 8 },
];
