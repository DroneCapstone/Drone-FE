import type { LockerSlot, Station } from '../types/operator';

function slots(stationId: string, count = 9): LockerSlot[] {
  return Array.from({ length: count }, (_, index) => ({
    id: `${stationId}-S${String(index + 1).padStart(2, '0')}`,
    stationId,
    status: 'Available' as const,
  }));
}

function linkedSlot(
  stationId: string,
  slotNumber: number,
  status: LockerSlot['status'],
  orderId?: string,
  missionId?: string,
): LockerSlot {
  return { id: `${stationId}-S${String(slotNumber).padStart(2, '0')}`, stationId, status, orderId, missionId };
}

export const defaultStations: Station[] = [
  {
    id: 'ST-01', name: 'Ben Thanh Station', area: 'District 1', address: 'District 1, Ho Chi Minh City',
    latitude: 10.772, longitude: 106.698, status: 'Active', slots: slots('ST-01'),
  },
  {
    id: 'ST-03', name: 'Thu Duc Station', area: 'Thu Duc', address: 'Thu Duc City, Ho Chi Minh City',
    latitude: 10.849, longitude: 106.771, status: 'Active', slots: slots('ST-03'),
  },
  {
    id: 'ST-05', name: 'Phu My Hung Station', area: 'District 7', address: 'District 7, Ho Chi Minh City',
    latitude: 10.729, longitude: 106.718, status: 'Active', slots: slots('ST-05'),
  },
  {
    id: 'ST-08', name: 'Binh Thanh Station', area: 'Binh Thanh', address: 'Binh Thanh District, Ho Chi Minh City',
    latitude: 10.803, longitude: 106.716, status: 'Active', slots: slots('ST-08'),
  },
];

function setSlot(stationId: string, slot: LockerSlot) {
  const station = defaultStations.find((item) => item.id === stationId);
  if (!station) return;
  const index = station.slots.findIndex((item) => item.id === slot.id);
  if (index >= 0) station.slots[index] = slot;
}

// Reserved slots belong to Scheduled/In-Progress delivery missions.
setSlot('ST-08', linkedSlot('ST-08', 8, 'Reserved', 'ORD-1103', 'MSN-3103'));
setSlot('ST-05', linkedSlot('ST-05', 8, 'Reserved', 'ORD-1104', 'MSN-3104'));
setSlot('ST-01', linkedSlot('ST-01', 8, 'Reserved', 'ORD-1110', 'MSN-3110'));

// Occupied slots contain packages physically waiting at the station.
setSlot('ST-05', linkedSlot('ST-05', 3, 'Occupied', 'ORD-1105', 'MSN-3105'));
setSlot('ST-08', linkedSlot('ST-08', 6, 'Occupied', 'ORD-1106', 'MSN-3106'));
setSlot('ST-03', linkedSlot('ST-03', 4, 'Occupied', 'ORD-1107', 'MSN-3107'));
setSlot('ST-05', linkedSlot('ST-05', 4, 'Occupied', 'ORD-1108', 'MSN-3108'));

// Example unavailable capacity kept separate from package lifecycle.
setSlot('ST-01', linkedSlot('ST-01', 9, 'Out of Service'));
setSlot('ST-05', linkedSlot('ST-05', 9, 'Out of Service'));
