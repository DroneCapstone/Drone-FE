import type { Order } from '../types/operator';

const isoFromNow = (minutes: number) => new Date(Date.now() + minutes * 60_000).toISOString();
const dateOnly = (iso: string) => iso.slice(0, 10);

function pendingOrder(
  id: string,
  pickupStationId: string,
  destinationStationId: string,
  startInMinutes: number,
  payloadKg: number,
  packageLabel: string,
  customerName: string,
  packageType = 'Standard parcel',
): Order {
  const start = isoFromNow(startInMinutes);
  const end = isoFromNow(startInMinutes + 30);
  return {
    id,
    customerName,
    customerPhone: '090 123 4567',
    packageLabel,
    packageType,
    payloadKg,
    pickupStationId,
    destinationStationId,
    requestedDate: dateOnly(start),
    initialEstimatedWindow: { start, end },
    currentEstimatedWindow: { start, end },
    planningAt: isoFromNow(startInMinutes - 60),
    status: 'Pending',
    returnStatus: 'None',
    charges: { deliveryFee: 65000, currency: 'VND' },
    createdAt: isoFromNow(-240),
  };
}

export const defaultOrders: Order[] = [
  // CASE 1 — Future order: planning window has not opened yet.
  pendingOrder('ORD-1101', 'ST-01', 'ST-05', 300, 2.2, 'Document parcel', 'Minh Nguyen'),

  // CASE 2 — Ready for mission planning: used as the main Create Mission + AI demo flow.
  pendingOrder('ORD-1102', 'ST-03', 'ST-05', 50, 3.2, 'Medical supplies', 'Trang Le'),

  // CASE 3 — Delivery Mission already scheduled.
  pendingOrder('ORD-1103', 'ST-01', 'ST-08', 120, 4.1, 'Electronics parcel', 'Khoa Tran'),

  // CASE 4 — Delivery Mission currently in progress.
  pendingOrder('ORD-1104', 'ST-03', 'ST-05', 20, 4.8, 'Retail replenishment', 'Anh Pham'),

  // CASE 5 — Package is at destination station and waiting for pickup.
  {
    ...pendingOrder('ORD-1105', 'ST-01', 'ST-05', -90, 2.8, 'Consumer parcel', 'Linh Vo'),
    status: 'Ready for Pickup',
    readyForPickupAt: isoFromNow(-60),
    pickupDeadline: isoFromNow(240),
    gracePeriodEndsAt: isoFromNow(255),
    packageDisposition: undefined,
  },

  // CASE 6 — Customer pickup deadline is close.
  {
    ...pendingOrder('ORD-1106', 'ST-03', 'ST-08', -120, 1.9, 'Contract documents', 'Huy Bui'),
    status: 'Ready for Pickup',
    readyForPickupAt: isoFromNow(-280),
    pickupDeadline: isoFromNow(20),
    gracePeriodEndsAt: isoFromNow(35),
  },

  // CASE 7 — Pickup deadline passed; customer is still inside the grace period.
  {
    ...pendingOrder('ORD-1107', 'ST-05', 'ST-03', -150, 2.6, 'Pharmacy parcel', 'Mai Ho'),
    status: 'Ready for Pickup',
    readyForPickupAt: isoFromNow(-305),
    pickupDeadline: isoFromNow(-5),
    gracePeriodEndsAt: isoFromNow(10),
  },

  // CASE 8 — Grace period expired; the system has already created a Return Mission.
  {
    ...pendingOrder('ORD-1108', 'ST-01', 'ST-05', -240, 3.5, 'Home appliance parts', 'Nam Do'),
    status: 'Ready for Pickup',
    readyForPickupAt: isoFromNow(-360),
    pickupDeadline: isoFromNow(-60),
    gracePeriodEndsAt: isoFromNow(-45),
    returnStatus: 'Return Planned',
    returnReason: 'Customer Pickup Timeout',
    charges: { deliveryFee: 65000, returnFee: 45000, currency: 'VND' },
  },

  // CASE 9 — Return completed and package confirmed at the original dispatch hub.
  {
    ...pendingOrder('ORD-1109', 'ST-03', 'ST-08', -420, 2.4, 'Replacement components', 'Bao Nguyen'),
    status: 'Returned',
    returnStatus: 'Returned to Hub',
    returnReason: 'Customer Pickup Timeout',
    packageDisposition: 'Returned',
    returnedAt: isoFromNow(-70),
    charges: { deliveryFee: 65000, returnFee: 45000, currency: 'VND' },
  },

  // CASE 10 — Active Mission with a replacement-drone history / operational incident.
  pendingOrder('ORD-1110', 'ST-05', 'ST-01', 25, 5.0, 'Network equipment', 'Tuan Lam'),

  // Closed examples for filters and audit-like detail pages.
  {
    ...pendingOrder('ORD-1111', 'ST-05', 'ST-01', -360, 3.5, 'Consumer parcel', 'Vy Tran'),
    status: 'Completed',
    packageDisposition: 'Delivered',
  },
  {
    ...pendingOrder('ORD-1112', 'ST-01', 'ST-03', -420, 2.1, 'Document parcel', 'Quang Pham'),
    status: 'Cancelled',
  },
];
