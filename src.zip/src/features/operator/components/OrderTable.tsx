import { useNavigate } from 'react-router-dom';
import { StatusBadge } from '../../../components/ui/StatusBadge';
import type { Mission, Order, PlanningState, Tone } from '../types/operator';
import {
  formatDeliveryWindow,
  getDeliveryMission,
  getOrderPlanningBadge,
  getReturnMission,
  isActionablePlanningState,
} from '../utils/deliveryPlanning';
import { getStation } from '../utils/stationCapacity';

function planningTone(state: PlanningState): Tone {
  if (state === 'Planning Overdue') return 'danger';
  if (state === 'Ready for Planning') return 'warning';
  if (state === 'Upcoming') return 'info';
  return 'neutral';
}

export function OrderTable({ orders, missions }: { orders: Order[]; missions: Mission[] }) {
  const navigate = useNavigate();

  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Order</th>
            <th>Pickup → Destination</th>
            <th>Package</th>
            <th>Estimated delivery</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => {
            const planning = getOrderPlanningBadge(order, missions);
            const deliveryMission = getDeliveryMission(order.id, missions);
            const returnMission = getReturnMission(order.id, missions);
            const pickup = getStation(order.pickupStationId)?.name ?? order.pickupStationId;
            const destination = getStation(order.destinationStationId)?.name ?? order.destinationStationId;
            const canCreate = isActionablePlanningState(planning);

            let action = 'Open';
            let target = `/operator/orders/${order.id}`;
            if (returnMission) {
              action = 'View return';
              target = `/operator/missions/${returnMission.id}`;
            } else if (order.status === 'Ready for Pickup') {
              action = 'View pickup';
            } else if (deliveryMission) {
              action = 'View mission';
              target = `/operator/missions/${deliveryMission.id}`;
            } else if (canCreate) {
              action = 'Create mission';
              target = `/operator/missions/create?orderId=${order.id}`;
            } else if (order.status === 'Returned') {
              action = 'View return';
            } else if (order.status === 'Completed' || order.status === 'Cancelled') {
              action = 'View';
            }

            return (
              <tr key={order.id} onClick={() => navigate(`/operator/orders/${order.id}`)}>
                <td><strong>{order.id}</strong><small>{order.customerName}</small></td>
                <td><strong>{pickup}</strong><small>→ {destination}</small></td>
                <td>{order.packageLabel}<small>{order.payloadKg} kg · {order.packageType}</small></td>
                <td>
                  <strong>{formatDeliveryWindow(order)}</strong>
                  <div className="order-delivery-meta">
                    {planning && <StatusBadge tone={planningTone(planning)}>{planning}</StatusBadge>}
                    {!planning && order.status !== 'Pending' && <small>{order.status}</small>}
                  </div>
                </td>
                <td>
                  <button
                    type="button"
                    className="row-action"
                    onClick={(event) => { event.stopPropagation(); navigate(target); }}
                  >
                    {action}
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
