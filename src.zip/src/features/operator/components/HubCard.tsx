import { Icon } from '../../../components/ui/Icon';
import { StatusBadge } from '../../../components/ui/StatusBadge';
import type { Hub } from '../types/operator';

interface HubCardProps {
  hub: Hub;
  totalDrones: number;
  readyDrones: number;
  distanceKm?: number;
  selected?: boolean;
  onSelect?: () => void;
}

export function HubCard({
  hub,
  totalDrones,
  readyDrones,
  distanceKm,
  selected = false,
  onSelect,
}: HubCardProps) {
  const content = (
    <>
      <div className="hub-card-head">
        <div>
          <span className="eyebrow">{hub.area}</span>
          <h3>{hub.name}</h3>
        </div>

        <StatusBadge tone={hub.status === 'Active' ? 'success' : 'neutral'}>
          {hub.status}
        </StatusBadge>
      </div>

      <div className="hub-card-location">
        <Icon name="pin" size={16} />
        <span>{hub.address}</span>
      </div>

      <div className="hub-card-stats">
        <span>
          <small>Total drones</small>
          <strong>{totalDrones}</strong>
        </span>
        <span>
          <small>Ready now</small>
          <strong>{readyDrones}</strong>
        </span>
        {distanceKm !== undefined && (
          <span>
            <small>From pickup</small>
            <strong>{distanceKm.toFixed(1)} km</strong>
          </span>
        )}
      </div>
    </>
  );

  if (onSelect) {
    return (
      <button
        type="button"
        className={`hub-card selectable-card ${selected ? 'active' : ''}`}
        onClick={onSelect}
        aria-pressed={selected}
      >
        {content}
      </button>
    );
  }

  return <div className="hub-card">{content}</div>;
}
