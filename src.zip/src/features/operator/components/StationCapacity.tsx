import type { Station } from '../types/operator';
import { getStationCounts } from '../utils/stationCapacity';

export function StationCapacity({ station }: { station: Station }) {
  const counts = getStationCounts(station);
  return (
    <div className="station-capacity-grid">
      <span><small>Total</small><strong>{counts.total}</strong></span>
      <span><small>Available</small><strong>{counts.available}</strong></span>
      <span><small>Reserved</small><strong>{counts.reserved}</strong></span>
      <span><small>Occupied</small><strong>{counts.occupied}</strong></span>
      <span><small>Out of service</small><strong>{counts.outOfService}</strong></span>
    </div>
  );
}
