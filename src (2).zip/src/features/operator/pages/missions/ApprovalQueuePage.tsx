// import { useState } from "react";
// import { ActionButton } from "../../../../components/ui/ActionButton";
// import { Icon } from "../../../../components/ui/Icon";
// import { StatusBadge } from "../../../../components/ui/StatusBadge";
// import { OperatorPanel } from "../../components/OperatorPanel";
// import { MissionPageShell } from "./MissionPageShell";

// export function ApprovalQueuePage() {
//   const [decision, setDecision] = useState("");
//   const [toast, setToast] = useState("");
//   const decide = (value: string) => {
//     setDecision(value);
//     setToast(
//       `Mission ${value.toLowerCase()}${value === "Approved" ? " for launch" : ""}`,
//     );
//     setTimeout(() => setToast(""), 2400);
//   };
//   return (
//     <MissionPageShell active="/operator/missions/approvals">
//       <div className="approval-layout">
//         <div className="queue-list">
//           <div className="queue-head">
//             <span>Waiting for review</span>
//             <span className="badge badge-neutral">3 pending</span>
//           </div>
//           {["MSN-2850", "MSN-2848", "MSN-2844"].map((id, index) => (
//             <button
//               className={`queue-card ${index === 0 ? "active" : ""}`}
//               key={id}
//             >
//               <span>
//                 <strong>
//                   {
//                     [
//                       "West bay urgent supply",
//                       "Industrial zone inspection",
//                       "Canal mapping run",
//                     ][index]
//                   }
//                 </strong>
//                 <small>
//                   {id} · submitted {index * 8 + 4} min ago
//                 </small>
//               </span>
//               <StatusBadge tone={index === 0 ? "danger" : "neutral"}>
//                 {index === 0 ? "High" : "Normal"}
//               </StatusBadge>
//             </button>
//           ))}
//         </div>
//         <OperatorPanel className="approval-detail">
//           <div className="approval-title">
//             <div>
//               <span className="eyebrow">APPROVAL REVIEW</span>
//               <h2>West bay urgent supply</h2>
//               <p>MSN-2850 · Submitted by Linh Tran</p>
//             </div>
//             {decision ? (
//               <StatusBadge
//                 tone={decision === "Approved" ? "success" : "danger"}
//               >
//                 {decision}
//               </StatusBadge>
//             ) : (
//               <StatusBadge tone="neutral">Pending</StatusBadge>
//             )}
//           </div>
//           <div
//             className="risk-banner"
//             style={{
//               color: "var(--text)",
//               background: "var(--surface-2)",
//               borderColor: "var(--border)",
//             }}
//           >
//             <div>
//               <strong>
//                 Risk assessment:{" "}
//                 <span style={{ color: "#e89b35" }}>Moderate</span>
//               </strong>
//               <span style={{ color: "var(--muted)" }}>
//                 Crosswind exposure is 12% above the preferred threshold at
//                 waypoint W-04.
//               </span>
//             </div>
//             <strong>72/100</strong>
//           </div>
//           <div className="approval-facts">
//             <span>
//               <small>Drone</small>
//               <strong>CX-09</strong>
//             </span>
//             <span>
//               <small>Distance</small>
//               <strong>22.6 km</strong>
//             </span>
//             <span>
//               <small>Payload</small>
//               <strong>6.2 kg</strong>
//             </span>
//             <span>
//               <small>Energy reserve</small>
//               <strong>28%</strong>
//             </span>
//           </div>
//           <h3>Pre-flight checklist</h3>
//           <div className="checklist">
//             <span>
//               <Icon name="check" />
//               Drone readiness verified
//             </span>
//             <span>
//               <Icon name="check" />
//               Payload within certified limit
//             </span>
//             <span>
//               <Icon name="check" />
//               Airspace authorization confirmed
//             </span>
//             <span className="warn" style={{ color: "var(--muted)" }}>
//               <Icon name="alert" />
//               Weather threshold requires operator review
//             </span>
//           </div>
//           <div className="approval-actions">
//             <ActionButton variant="danger" onClick={() => decide("Rejected")}>
//               Reject
//             </ActionButton>
//             <ActionButton onClick={() => decide("Approved")}>
//               Approve mission
//             </ActionButton>
//           </div>
//         </OperatorPanel>
//         {toast && (
//           <div className="toast">
//             <Icon name="check" />
//             {toast}
//           </div>
//         )}
//       </div>
//     </MissionPageShell>
//   );
// }

import { useState } from "react";

import { ActionButton } from "../../../../components/ui/ActionButton";
import { Icon } from "../../../../components/ui/Icon";
import { StatusBadge } from "../../../../components/ui/StatusBadge";

import { OperatorPanel } from "../../components/OperatorPanel";

import { MissionPageShell } from "./MissionPageShell";

const approvalMissions = [
  {
    id: "MSN-2850",
    name: "West bay urgent supply",
    submitted: "4 min ago",
    priority: "High",
    tone: "danger" as const,
  },
  {
    id: "MSN-2848",
    name: "Industrial zone inspection",
    submitted: "12 min ago",
    priority: "Normal",
    tone: "neutral" as const,
  },
  {
    id: "MSN-2844",
    name: "Canal mapping run",
    submitted: "20 min ago",
    priority: "Normal",
    tone: "neutral" as const,
  },
];

export function ApprovalQueuePage() {
  const [selectedMissionId, setSelectedMissionId] = useState(
    approvalMissions[0].id,
  );

  const [decision, setDecision] = useState("");
  const [toast, setToast] = useState("");

  const decide = (value: string) => {
    setDecision(value);

    setToast(
      `Mission ${value.toLowerCase()}${value === "Approved" ? " for launch" : ""
      }`,
    );

    setTimeout(() => setToast(""), 2400);
  };

  return (
    <MissionPageShell active="/operator/missions/approvals">
      <div className="approval-layout">
        {/* =========================
            APPROVAL QUEUE
        ========================= */}

        <div className="queue-list">
          <div className="queue-head">
            <span>Waiting for review</span>

            <span className="badge badge-neutral">
              {approvalMissions.length} pending
            </span>
          </div>

          {approvalMissions.map((mission) => {
            const isSelected = selectedMissionId === mission.id;

            return (
              <button
                key={mission.id}
                type="button"
                className={`queue-card selectable-card ${isSelected ? "active" : ""
                  }`}
                onClick={() => {
                  setSelectedMissionId(mission.id);

                  /*
                   * Khi chọn mission khác,
                   * reset trạng thái approve/reject cũ.
                   */
                  setDecision("");
                }}
              >
                <span>
                  <strong>{mission.name}</strong>

                  <small>
                    {mission.id} · submitted {mission.submitted}
                  </small>
                </span>

                <StatusBadge tone={mission.tone}>
                  {mission.priority}
                </StatusBadge>
              </button>
            );
          })}
        </div>

        {/* =========================
            APPROVAL DETAIL
        ========================= */}

        <OperatorPanel className="approval-detail">
          <div className="approval-title">
            <div>
              <span className="eyebrow">APPROVAL REVIEW</span>

              <h2>West bay urgent supply</h2>

              <p>MSN-2850 · Submitted by Linh Tran</p>
            </div>

            {decision ? (
              <StatusBadge
                tone={decision === "Approved" ? "success" : "danger"}
              >
                {decision}
              </StatusBadge>
            ) : (
              <StatusBadge tone="neutral">Pending</StatusBadge>
            )}
          </div>

          <div
            className="risk-banner"
            style={{
              color: "var(--text)",
              background: "var(--surface-2)",
              borderColor: "var(--border)",
            }}
          >
            <div>
              <strong>
                Risk assessment:{" "}
                <span style={{ color: "#e89b35" }}>Moderate</span>
              </strong>

              <span style={{ color: "var(--muted)" }}>
                Crosswind exposure is 12% above the preferred threshold at
                waypoint W-04.
              </span>
            </div>

            <strong>72/100</strong>
          </div>

          <div className="approval-facts">
            <span>
              <small>Drone</small>
              <strong>CX-09</strong>
            </span>

            <span>
              <small>Distance</small>
              <strong>22.6 km</strong>
            </span>

            <span>
              <small>Payload</small>
              <strong>6.2 kg</strong>
            </span>

            <span>
              <small>Energy reserve</small>
              <strong>28%</strong>
            </span>
          </div>

          <h3>Pre-flight checklist</h3>

          <div className="checklist">
            <span>
              <Icon name="check" />
              Drone readiness verified
            </span>

            <span>
              <Icon name="check" />
              Payload within certified limit
            </span>

            <span>
              <Icon name="check" />
              Airspace authorization confirmed
            </span>

            <span className="warn" style={{ color: "var(--muted)" }}>
              <Icon name="alert" />
              Weather threshold requires operator review
            </span>
          </div>

          <div className="approval-actions">
            <ActionButton
              variant="danger"
              onClick={() => decide("Rejected")}
            >
              Reject
            </ActionButton>

            <ActionButton onClick={() => decide("Approved")}>
              Approve mission
            </ActionButton>
          </div>
        </OperatorPanel>

        {toast && (
          <div className="toast">
            <Icon name="check" />
            {toast}
          </div>
        )}
      </div>
    </MissionPageShell>
  );
}